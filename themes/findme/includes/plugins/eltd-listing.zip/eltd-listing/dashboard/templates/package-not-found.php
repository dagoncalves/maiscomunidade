<p class="eltd-ls-not-found">
    <?php esc_html_e( "Sorry, you don't have any package.", 'eltd-listing' );?>
</p>