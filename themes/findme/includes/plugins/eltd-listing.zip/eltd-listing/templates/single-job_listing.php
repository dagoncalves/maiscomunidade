<?php
get_header();
eltd_listing_single_listing();
get_footer();