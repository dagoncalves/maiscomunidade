<?php
echo findme_elated_get_module_part( $article_obj->getPriceHtml() );