<div class="eltd-ls-single-comments">
    <?php comments_template('', true); ?>
</div>