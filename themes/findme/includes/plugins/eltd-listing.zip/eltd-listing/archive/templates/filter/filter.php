<div class="eltd-listing-archive-filter-holder clearfix">

	<?php
        eltd_listing_get_archive_module_template_part('filter/parts/results');
	    eltd_listing_get_archive_module_template_part('filter/parts/keyword');
	    eltd_listing_get_archive_module_template_part('filter/parts/location');
	    eltd_listing_get_archive_module_template_part('filter/parts/type');
	    eltd_listing_get_archive_module_template_part('filter/parts/category');
	    eltd_listing_get_archive_module_template_part('filter/parts/address');
	    eltd_listing_get_archive_module_template_part('filter/parts/amenities');
	    eltd_listing_get_archive_module_template_part('filter/parts/submit');
	?>

</div>