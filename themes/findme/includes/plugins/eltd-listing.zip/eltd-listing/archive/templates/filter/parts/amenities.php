<!--	selected type amenities will be stored in this holder-->
<div class="eltd-listing-type-amenities-holder eltd-ls-archive-filter-item eltd-full-width-item"></div>