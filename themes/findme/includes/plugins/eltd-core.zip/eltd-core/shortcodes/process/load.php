<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/process/helper.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/process/process-holder.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/process/process.php';