<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/blockquote/function.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/blockquote/blockquote.php';