<div class="eltd-content-slider eltd-owl-slider <?php echo esc_attr($content_slider_classes); ?>" <?php echo findme_elated_get_inline_attrs($content_slider_data); ?>>
    <?php echo do_shortcode($content); ?>
</div>