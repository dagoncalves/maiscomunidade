<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/content-slider/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/content-slider/content-slider-holder.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/content-slider/content-slider.php';