<div class="eltd-iwt-slider-holder clearfix eltd-owl-slider <?php echo esc_attr($iwt_class)?>" <?php echo findme_elated_get_inline_attrs($data_attr)  ?>>
	<?php echo do_shortcode($content); ?>
</div>
