<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/icon-with-text-slider/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/icon-with-text-slider/icon-with-text-slider.php';