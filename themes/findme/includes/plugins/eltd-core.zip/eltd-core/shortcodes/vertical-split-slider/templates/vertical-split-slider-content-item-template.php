<div class="eltd-vss-ms-section" <?php echo findme_elated_get_inline_attrs($content_data); ?> <?php findme_elated_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>