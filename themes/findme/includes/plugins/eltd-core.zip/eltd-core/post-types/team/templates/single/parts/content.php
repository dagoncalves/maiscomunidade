<div class="eltd-team-single-content">
	<?php the_content(); ?>
</div>